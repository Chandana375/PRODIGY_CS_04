﻿import psutil, os, csv, time, tkinter as tk
from tkinter import messagebox
from datetime import datetime

# Settings
suspicious_keywords = ['keylog','hook','pynput','keyboard','listener']
watch_files = ['keylog.txt','keystrokes.txt','log.txt']
log_file = os.path.join(os.getcwd(),'edr_report.csv')
whitelist = ['python.exe','powershell.exe','cmd.exe','code.exe']

# GUI
root = tk.Tk()
root.title('Mini EDR Dashboard')
root.geometry('600x400')
text = tk.Text(root)
text.pack(fill=tk.BOTH, expand=True)

# Color tags
text.tag_configure('HIGH', foreground='red', font=('Arial',10,'bold'))
text.tag_configure('LOW', foreground='green', font=('Arial',10,'normal'))

# Scan function
def scan():
    findings=[]
    files=[]
    for proc in psutil.process_iter(['pid','name','cmdline']):
        try:
            name=(proc.info['name'] or '').lower()
            if name in whitelist: continue
            cmd=' '.join(proc.info['cmdline'] or []).lower()
            score=sum(1 for w in suspicious_keywords if w in cmd or w in name)
            if score>0: findings.append((datetime.now(), proc.info['pid'], name, 'HIGH', score))
        except: pass
    for f in os.listdir('.'):
        if f.lower() in watch_files: files.append(f)
    return findings, files

def save_csv(data):
    write_header = not os.path.exists(log_file)
    with open(log_file,'a', newline='') as f:
        writer = csv.writer(f)
        if write_header: writer.writerow(['Time','PID','Process','Risk','Score'])
        writer.writerows(data)

# Simulate keylogger file
with open('keylog.txt','w') as f:
    for i in range(5): f.write(f'Simulated keystroke {i+1}\n')
time.sleep(0.5)

# GUI update
def update():
    findings, files = scan()
    text.delete(1.0, tk.END)
    if findings:
        for f in findings:
            line = f'{f[0]} | PID:{f[1]} | {f[2]} | {f[3]} | {f[4]}'
            text.insert(tk.END, line+'\n', f[3])
            if f[3]=='HIGH': messagebox.showwarning('EDR ALERT', line)
        save_csv(findings)
    else:
        text.insert(tk.END, "No suspicious processes\n", 'LOW')
    if files:
        text.insert(tk.END, "\nSuspicious Files:\n", 'HIGH')
        for file in files: text.insert(tk.END, file+'\n', 'HIGH')
    root.after(5000, update)

update()
root.mainloop()
